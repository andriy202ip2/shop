<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Product
 *
 * @author Prog1
 */
class Product {
    //put your code here
    
    public $Id, $Id_categories, $Id_sub_categories, $Name, $Count, $Description, $Prise;
    
    public $CategoriName, $SubCategoriName;
    
    
    
}
