
<center><h1 class="red">Admin Panel !!!</h1><br/>

<h2>
<a href="/Admin/Users/"> Users Admin</a><br/><br/>
<a href="/Admin/Categories/"> Categories Admin</a><br/><br/>
<a href="/Admin/SubCategories/"> SubCategories Admin</a><br/><br/>
<a href="/Admin/Orders/"> Orders Admin</a><br/><br/>
<a href="/Admin/Products/"> Products Admin</a><br/><br/>

</h2>

    
    
    
    
</center>