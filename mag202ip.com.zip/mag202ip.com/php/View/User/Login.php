
<input class="button login-button" type="submit" value="login" />


<div id="dialog-login" title="Login !" style="display: none">

<label class="loginform">
    
        <label for="Email">Email:<br/>
            <input type="email" name="Email" placeholder="yourname@email.com" required>
            <label class="E"></label>
        </label><br/>
        
        <label for="Pass">Password:<br/>
        <input type="password" name="Pass" placeholder="password" required>
        <label class="E"></label>
        </label><br/>
            
        <br/>
        <label for="g-recaptcha-response">
        <div id="Recaptcha"></div>
        <label class="E"></label>
        </label>
        
        <center><a href="#" id="register-button">or Register</a></center>
        
</label>
</div>

<div id="dialog-register" title="Register !" style="display: none">

<section class="registerform">
    
        <label for="Email">Email:<br/>
            <input type="email" name="Email" placeholder="yourname@email.com" required>
            <label class="E"></label>
        </label><br/>
        
        <label for="Pass">Password:<br/>
        <input type="password" name="Pass" placeholder="password" required>
        <label class="E"></label>
        </label><br/>      
        
        <label for="Pass2">Re enter Password:<br/>
        <input type="password" name="Pass2" placeholder="password" required>
        <label class="E"></label>
        </label><br/>    
        
        <label for="FirstName">First Name:<br/>
        <input type="text" name="FirstName" placeholder="First Name" required>
        <label class="E"></label>
        </label><br/>  
        
        <label for="LastName">Last Name:<br/>
        <input type="text" name="LastName" placeholder="Last Name" required>
        <label class="E"></label>
        </label><br/>
         
        <br/>
        <label for="g-recaptcha-response">
        <div id="Recaptcha2"></div>
        <label class="E"></label>
        </label>
        
</section>
</div>

